from django.apps import AppConfig


class FaceAppConfig(AppConfig):
    name = 'face_app'
